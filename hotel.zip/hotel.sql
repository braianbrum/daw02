
CREATE TABLE IF NOT EXISTS `hotel`.`usuarios` (
  `id_usuario` INT NOT NULL,
  `nome` VARCHAR(45) NULL,
  `sobrenome` VARCHAR(45) NULL,
  `email` VARCHAR(45) NULL,
  `senha` VARCHAR(45) NULL,
  `telefone` INT NULL,
  `endereco` VARCHAR(45) NULL,
  `cidade` VARCHAR(45) NULL,
  `doc_identificacao` VARCHAR(45) NULL,
  PRIMARY KEY (`id_usuario`));



-- -----------------------------------------------------
-- Table `bancoHotel`.`clientes`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hotel`.`clientes` (
  `id_cliente` INT NOT NULL,
  `nome` VARCHAR(45) NULL,
  `sobrenome` VARCHAR(45) NULL,
  `e-mail` VARCHAR(45) NULL,
  `senha` VARCHAR(45) NULL,
  `telefone` INT NULL,
  `endereco` VARCHAR(45) NULL,
  `doc_idendificacao` VARCHAR(45) NULL,
  PRIMARY KEY (`id_cliente`));



-- -----------------------------------------------------
-- Table `hotel`.`quartos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hotel`.`quartos` (
  `nro_porta` INT NOT NULL,
  `descricaoQuarto` VARCHAR(100) NULL,
  `preco` DECIMAL(20) NULL,
  PRIMARY KEY (`nro_porta`));


-- -----------------------------------------------------
-- Table `hotel`.`reservas`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hotel`.`reservas` (
  `id_reservas` INT NOT NULL,
  `clientes_id_cliente` INT NOT NULL,
  `dataInicial` DATE NULL,
  `dataFinal` DATE NULL,
  `quartos_nro_porta` INT NOT NULL,
  PRIMARY KEY (`id_reservas`),
  INDEX `fk_reservas_clientes_idx` (`clientes_id_cliente` ASC),
  INDEX `fk_reservas_quartos1_idx` (`quartos_nro_porta` ASC),
  CONSTRAINT `fk_reservas_clientes`
    FOREIGN KEY (`clientes_id_cliente`)
    REFERENCES `hotel`.`clientes` (`id_cliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_reservas_quartos1`
    FOREIGN KEY (`quartos_nro_porta`)
    REFERENCES `hotel`.`quartos` (`nro_porta`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);



-- -----------------------------------------------------
-- Table `hotel`.`post`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hotel`.`post` (
  `id_post` INT NOT NULL,
  `datadia` DATE NULL,
  `hora` VARCHAR(45) NULL,
  `imagem` VARCHAR(100) NULL,
  `texto` VARCHAR(800) NULL,
  `usuarios_id_usuario` INT NOT NULL,
  PRIMARY KEY (`id_post`),
  INDEX `fk_post_usuarios1_idx` (`usuarios_id_usuario` ASC),
  CONSTRAINT `fk_post_usuarios1`
    FOREIGN KEY (`usuarios_id_usuario`)
    REFERENCES `hotel`.`usuarios` (`id_usuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION);


INSERT INTO usuarios(nome) VALUES('byat78dew');
SELECT nome FROM usuarios;